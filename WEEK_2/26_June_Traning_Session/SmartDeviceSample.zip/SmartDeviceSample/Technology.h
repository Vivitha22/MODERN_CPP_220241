#ifndef TECHNOLOGY_H
#define TECHNOLOGY_H

enum Technology {
    BLUETOOTH,
    WIFI,
    BLUETOOTH_WIFI,
    OTHER
};

#endif // TECHNOLOGY_H
