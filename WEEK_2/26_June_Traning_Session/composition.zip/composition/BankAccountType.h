#ifndef BANACCOUNTTYPE_H
#define BANACCOUNTTYPE_H

enum class BankAccountType{
    SAVINGS,
    CURRENT,
    PENSION
};

#endif // BANACCOUNTTYPE_H
