#ifndef DEBITCARDTYPE_H
#define DEBITCARDTYPE_H

enum class DebitCardType{
    VISA,
    MASTERCARD,
    AMEX,
    DINERSCLUB
};

#endif // DEBITCARDTYPE_H
