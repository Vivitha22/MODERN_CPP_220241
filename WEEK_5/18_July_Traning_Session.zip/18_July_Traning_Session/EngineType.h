#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType{
    HYBRID,
    REGULAR,
    NA
};

#endif // ENGINETYPE_H
