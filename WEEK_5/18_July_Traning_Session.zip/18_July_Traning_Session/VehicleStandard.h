#ifndef VEHICLESTANDARD_H
#define VEHICLESTANDARD_H

enum class VehicleStandard{
    BS6,
    NS6_2, BS4,
    OTHER
};

#endif // VEHICLESTANDARD_H
