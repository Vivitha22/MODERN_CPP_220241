#ifndef FUELTYPE_H
#define FUELTYPE_H

enum class FuelType{
    ICE,
    ALTERNATE_FUEL,
    OTHER
};

#endif // FUELTYPE_H
