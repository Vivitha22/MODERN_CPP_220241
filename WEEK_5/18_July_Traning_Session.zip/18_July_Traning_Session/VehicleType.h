#ifndef VEHICLETYPE_H
#define VEHICLETYPE_H

enum class VehicleType{
    PRIVATE,
    COMMERCIAL, 
    RENTAL
};

#endif // VEHICLETYPE_H
