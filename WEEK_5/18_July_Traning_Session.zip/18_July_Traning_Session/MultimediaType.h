#ifndef MULTIMEDIA_TYPE_H
#define MULTIMEDIA_TYPE_H

enum class MultimediaType{
    ANALOG,
    ANDROID_SMART,
    APPLE_ANDROID_SMART,
    APPLE_SMART
};

#endif // MULTIMEDIA_TYPE_H
