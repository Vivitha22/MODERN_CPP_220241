#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType{
    HYBRID,
    ICE,
    ALTERNATE_FUEL
};

#endif // ENGINETYPE_H
