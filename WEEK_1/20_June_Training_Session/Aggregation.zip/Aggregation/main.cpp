#include "functionality.h"
// #include<vector>

int main(){
    // using 
    std::vector<employee*> e;
    std::vector<project*> p;
    createObeject(e,p);
    deallocate(e,p); 

}