#include "Functionalities.h"

int main() {
    // BankAccount* accounts[2];
    std::vector<BankAccount*> accounts;
    CreateObjects(accounts);
    
    /*
        write other parts of client code here
    */
   DeallocateMemory(accounts);
}