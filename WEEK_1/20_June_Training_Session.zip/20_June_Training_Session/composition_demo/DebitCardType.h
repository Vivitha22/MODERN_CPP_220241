#ifndef DEBITCARDTYPE_H
#define DEBITCARDTYPE_H

enum DebitCardType {
    VISA,
    MASTERCARD,
    AMEX,
    DINERSCLUB
};

#endif // DEBITCARD_H
