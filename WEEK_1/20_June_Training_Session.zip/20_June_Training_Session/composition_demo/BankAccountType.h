#ifndef BANKACCOUNTTYPE_H
#define BANKACCOUNTTYPE_H

enum BankAccountType {
    SAVINGS,
    CURRENT,
    PENSION
};

#endif // BANKACCOUNT_H
