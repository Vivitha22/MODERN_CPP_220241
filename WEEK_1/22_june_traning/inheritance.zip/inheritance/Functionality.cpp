#include "Functionality.h"

void createObjects(container &c)
{
    c.emplace_back(new ICECar(101,"Vivi",202.3f,123,FuelType::PETROL));
    c.emplace_back(new ICECar(102,"Pavan", 45.5f,456,FuelType::DIESEL));

    c.emplace_back(new EvCar(103,"Vigi", 4520.2f,789.0f,12));
    c.emplace_back(new EvCar(104,"Prabhu", 7412.9f,852.2f,45));
    // new ICECar("ic101", "Dizire", 900.0f, FuelType::PETROL,42);
}



void Deallocate(container &c)
{
    for(const Car* v:c){
        delete v;
    }
}
