#ifndef EVCAR_H
#define EVCAR_H

#include "Car.h"


class EvCar : public Car
{
private:

    float evCarBatteryCapacity;
    unsigned int evCarRatedRange;

public:
    EvCar(int id, std::string name, float price ,float capacity, unsigned int range);
    ~EvCar();
};

#endif // EVCAR_H
