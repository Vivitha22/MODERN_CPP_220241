#ifndef CAR_H
#define CAR_H

#include<iostream>

class Car
{
private:
    int m_id;
    std::string m_modelName;
    float m_price;

public:
    Car(int id, std::string name, float price);
    ~Car();
};

#endif // CAR_H
