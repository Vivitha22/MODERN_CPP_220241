#ifndef BATTERYTYPE_H
#define BATTERYTYPE_H

enum class BatteryType{
    LI_ON,
    NI_CAR,
    OTHER
};

#endif // BATTERYTYPE_H
