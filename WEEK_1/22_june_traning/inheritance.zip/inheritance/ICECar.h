#ifndef ICECAR_H
#define ICECAR_H

#include "Car.h"
#include "FuelType.h"

class ICECar : public Car
{
private:
    FuelType iceCarFuelType;
    int iceCarFuelCapacity;

public:
    ICECar(int id, std::string name, float price ,int capacity,FuelType fueltype);
    ~ICECar();
};

#endif // ICECAR_H
